package vn.iotstar.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.service.UserService;
import vn.iotstar.service.impl.UserServiceImpl;

import java.io.IOException;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/register")
public class RegisterController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession(false);

		if (session != null && session.getAttribute("account") != null) {

			resp.sendRedirect(req.getContextPath() + "/admin/category/list");
			return;
		}

		req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	        throws ServletException, IOException {

	    req.setCharacterEncoding("UTF-8");

	    String username = req.getParameter("username");
	    String password = req.getParameter("password");
	    String confirmPassword = req.getParameter("confirmPassword");
	    String email = req.getParameter("email");
	    String fullname = req.getParameter("fullname");
	    String phone = req.getParameter("phone");

	    if (username == null || username.trim().isEmpty()
	            || password == null || password.trim().isEmpty()
	            || confirmPassword == null || confirmPassword.trim().isEmpty()
	            || email == null || email.trim().isEmpty()
	            || fullname == null || fullname.trim().isEmpty()
	            || phone == null || phone.trim().isEmpty()) {

	        req.setAttribute("alert", "Vui lòng nhập đầy đủ thông tin!");
	        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	        return;
	    }

	    if (password.length() < 6) {

	        req.setAttribute("alert", "Mật khẩu phải có ít nhất 6 ký tự!");
	        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	        return;
	    }

	    if (!password.equals(confirmPassword)) {

	        req.setAttribute("alert", "Mật khẩu xác nhận không khớp!");
	        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	        return;
	    }

	    UserService service = new UserServiceImpl();

	    if (service.checkExistEmail(email)) {

	        req.setAttribute("alert", "Email đã tồn tại!");
	        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	        return;
	    }

	    if (service.checkExistUsername(username)) {

	        req.setAttribute("alert", "Tài khoản đã tồn tại!");
	        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	        return;
	    }

	    boolean isSuccess = service.register(
	            username, password, email, fullname, phone
	    );

	    if (isSuccess) {

	        req.getSession().setAttribute("otpType", "register");

	        resp.sendRedirect(req.getContextPath() + "/verify-otp");

	    } else {

	        req.setAttribute("alert", "Đăng ký thất bại!");
	        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
	    }
	}
}
