package vn.iotstar.controller;

import java.io.File;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.iotstar.model.Profile;
import vn.iotstar.model.User;
import vn.iotstar.service.ProfileService;
import vn.iotstar.service.impl.ProfileServiceImpl;

@WebServlet("/profile")
@MultipartConfig
public class ProfileController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private ProfileService profileService = new ProfileServiceImpl();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		User user = (User) request.getSession().getAttribute("account");

		if (user == null) {
			response.sendRedirect(request.getContextPath() + "/login");
			return;
		}

		int id = user.getId();

		Profile profile = profileService.findById(id);

		request.setAttribute("profile", profile);

		request.getRequestDispatcher("/views/profile.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		User user = (User) request.getSession()
		        .getAttribute("account");

		if (user == null) {
		    response.sendRedirect(
		            request.getContextPath() + "/login");
		    return;
		}

		int id = user.getId();

		String fullname = request.getParameter("fullname");
		String phone = request.getParameter("phone");

		Profile profile = profileService.findById(id);

		profile.setFullname(fullname);
		profile.setPhone(phone);

		Part filePart = request.getPart("images");

		if (filePart != null && filePart.getSize() > 0) {

			String fileName = filePart.getSubmittedFileName();

			// Thư mục lưu ảnh
			String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";

			File uploadDir = new File(uploadPath);

			if (!uploadDir.exists()) {
				uploadDir.mkdirs();
			}

			String newFileName = System.currentTimeMillis() + "_" + fileName;

			String filePath = uploadPath + File.separator + newFileName;

			filePart.write(filePath);

			profile.setImages(newFileName);
		}

		profileService.update(profile);

		response.sendRedirect(request.getContextPath() + "/profile");
	}
}