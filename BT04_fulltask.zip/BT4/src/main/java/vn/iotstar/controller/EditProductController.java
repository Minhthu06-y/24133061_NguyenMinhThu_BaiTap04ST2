package vn.iotstar.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.iotstar.dao.ProductDao;
import vn.iotstar.dao.impl.ProductDaoImpl;
import vn.iotstar.model.Product;

@WebServlet("/edit-product")
public class EditProductController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	ProductDao productDao = new ProductDaoImpl();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));

		Product product = productDao.get(id);

		request.setAttribute("product", product);

		request.getRequestDispatcher("/views/admin/products/edit.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String idStr = request.getParameter("id");
		String productname = request.getParameter("productname");
		String description = request.getParameter("description");
		String priceStr = request.getParameter("price");
		String images = request.getParameter("images");
		String cateIDStr = request.getParameter("cateID");

		if (idStr == null || idStr.trim().isEmpty() || productname == null || productname.trim().isEmpty()
				|| description == null || description.trim().isEmpty() || images == null || images.trim().isEmpty()
				|| priceStr == null || priceStr.trim().isEmpty() || cateIDStr == null || cateIDStr.trim().isEmpty()) {

			request.setAttribute("alert", "Vui lòng nhập đầy đủ thông tin!");

			request.getRequestDispatcher("/views/admin/products/edit.jsp").forward(request, response);
			return;
		}

		int id;
		int cateID;
		double price;

		try {

			id = Integer.parseInt(idStr);
			cateID = Integer.parseInt(cateIDStr);
			price = Double.parseDouble(priceStr);

		} catch (NumberFormatException e) {

			request.setAttribute("alert", "Dữ liệu không hợp lệ!");

			request.getRequestDispatcher("/views/admin/products/edit.jsp").forward(request, response);
			return;
		}

		if (price <= 0) {

			request.setAttribute("alert", "Giá sản phẩm phải lớn hơn 0!");

			request.getRequestDispatcher("/views/admin/products/edit.jsp").forward(request, response);
			return;
		}

		Product product = new Product();

		product.setId(id);

		product.setProductname(productname);

		product.setDescription(description);

		product.setPrice(price);

		product.setImages(images);

		product.setCateID(cateID);

		productDao.update(product);

		response.sendRedirect(request.getContextPath() + "/manage-product");
	}
}