package vn.iotstar.controller;

import java.io.IOException;
import java.sql.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.iotstar.dao.ProductDao;
import vn.iotstar.dao.impl.ProductDaoImpl;
import vn.iotstar.model.Product;

@WebServlet("/add-product")
public class AddProductController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    ProductDao productDao = new ProductDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/views/admin/products/add.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String productname = request.getParameter("productname");
        String description = request.getParameter("description");
        String priceStr = request.getParameter("price");
        String images = request.getParameter("images");
        String cateIDStr = request.getParameter("cateID");

        if (productname == null || productname.trim().isEmpty()
                || description == null || description.trim().isEmpty()
                || images == null || images.trim().isEmpty()
                || priceStr == null || priceStr.trim().isEmpty()
                || cateIDStr == null || cateIDStr.trim().isEmpty()) {

            request.setAttribute("alert",
                    "Vui lòng nhập đầy đủ thông tin!");

            request.getRequestDispatcher(
                    "/views/admin/products/add.jsp"
            ).forward(request, response);

            return;
        }

        double price;
        int cateID;

        try {
            price = Double.parseDouble(priceStr);
            cateID = Integer.parseInt(cateIDStr);

            if (price <= 0) {
                request.setAttribute("alert",
                        "Giá sản phẩm phải lớn hơn 0!");

                request.getRequestDispatcher(
                        "/views/admin/products/add.jsp"
                ).forward(request, response);

                return;
            }

        } catch (NumberFormatException e) {

            request.setAttribute("alert",
                    "Giá hoặc danh mục không hợp lệ!");

            request.getRequestDispatcher(
                    "/views/admin/products/add.jsp"
            ).forward(request, response);

            return;
        }
        
        Product product = new Product();

        product.setProductname(productname);
        product.setDescription(description);
        product.setPrice(price);
        product.setImages(images);
        product.setCateID(cateID);

        product.setCreatedDate(
            new Date(System.currentTimeMillis())
        );

        productDao.insert(product);

        response.sendRedirect(
            request.getContextPath() + "/manage-product"
        );
    }
}