package vn.iotstar.dao.impl;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import vn.iotstar.connection.JPAConnect;
import vn.iotstar.dao.ProfileDao;
import vn.iotstar.model.Profile;

public class ProfileDaoImpl implements ProfileDao {

	@Override
	public Profile findById(int id) {

		EntityManager entityManager = JPAConnect.getEntityManager();

		try {
			return entityManager.find(Profile.class, id);

		} finally {
			entityManager.close();
		}
	}

	@Override
	public void update(Profile profile) {

		EntityManager entityManager = JPAConnect.getEntityManager();

		EntityTransaction transaction = entityManager.getTransaction();

		try {
			transaction.begin();

			entityManager.merge(profile);

			transaction.commit();

		} catch (Exception e) {

			if (transaction.isActive()) {
				transaction.rollback();
			}

			e.printStackTrace();

		} finally {
			entityManager.close();
		}
	}
}