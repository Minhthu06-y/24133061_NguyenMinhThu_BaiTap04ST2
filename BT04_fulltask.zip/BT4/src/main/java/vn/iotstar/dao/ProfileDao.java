package vn.iotstar.dao;

import vn.iotstar.model.Profile;

public interface ProfileDao {
	
	Profile findById(int id);

    void update(Profile profile);

}
