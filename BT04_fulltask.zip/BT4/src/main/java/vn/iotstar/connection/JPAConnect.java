package vn.iotstar.connection;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class JPAConnect {

    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("ShoppingServiceMVC");

    public static EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
}