package vn.iotstar.service.impl;

import vn.iotstar.dao.ProfileDao;
import vn.iotstar.dao.impl.ProfileDaoImpl;
import vn.iotstar.model.Profile;
import vn.iotstar.service.ProfileService;

public class ProfileServiceImpl implements ProfileService {

    private ProfileDao profileDao = new ProfileDaoImpl();

    @Override
    public Profile findById(int id) {

        return profileDao.findById(id);
    }

    @Override
    public void update(Profile profile) {

        profileDao.update(profile);
    }
}