package vn.iotstar.service;

import vn.iotstar.model.Profile;

public interface ProfileService {

    Profile findById(int id);

    void update(Profile profile);
}