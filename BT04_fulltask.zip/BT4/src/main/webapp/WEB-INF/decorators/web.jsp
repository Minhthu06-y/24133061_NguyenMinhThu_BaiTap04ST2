<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title><sitemesh:write property="title" /></title>

<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
	rel="stylesheet">

<style>
body {
	margin: 0;
	background: #f5f6fa;
	font-family: Arial, sans-serif;
}

/* NAVBAR */
.header {
	background: #2c3e50;
	color: white;
	padding: 20px 60px;
	display: flex;
	justify-content: space-between;
	align-items: center;
}

.logo {
	font-size: 24px;
	font-weight: bold;
}

.menu a {
	color: white;
	text-decoration: none;
	margin-left: 25px;
}

.menu a:hover {
	color: #3498db;
}
</style>

<sitemesh:write property="head" />

</head>

<body>

	<!-- NAVBAR -->

	<div class="header">

		<div class="logo">Campamela</div>

		<div class="menu">

			<a href="${pageContext.request.contextPath}/home"> Trang chủ </a> <a
				href="${pageContext.request.contextPath}/product"> Sản phẩm </a>

			<c:choose>

				<c:when test="${not empty sessionScope.account}">

					<a href="${pageContext.request.contextPath}/admin/category/list">
						Quản lý danh mục </a>

				</c:when>

				<c:otherwise>

					<a href="${pageContext.request.contextPath}/login"> Quản lý
						danh mục </a>

				</c:otherwise>

			</c:choose>


			<c:choose>

				<c:when test="${not empty sessionScope.account}">

					<a href="${pageContext.request.contextPath}/profile"> Thông tin
						cá nhân </a>

					<a href="${pageContext.request.contextPath}/manage-product">
						Quản lý sản phẩm </a>

					<a href="${pageContext.request.contextPath}/logout"> Đăng xuất
					</a>

				</c:when>


				<c:otherwise>

					<a href="${pageContext.request.contextPath}/login"> Đăng nhập </a>

					<a href="${pageContext.request.contextPath}/register"> Đăng ký
					</a>

				</c:otherwise>

			</c:choose>

		</div>

	</div>



	<main>

		<sitemesh:write property="body" />

	</main>



	<footer class="bg-dark text-white text-center p-3 mt-5">

		<p class="mb-0">© 2026 Campamela Shop</p>

	</footer>


	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
		
	</script>

</body>

</html>