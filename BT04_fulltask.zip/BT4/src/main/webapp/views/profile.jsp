<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Thông tin cá nhân</title>

<style>
    .profile-container {
        width: 500px;
        margin: 50px auto;
        padding: 30px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 0 10px #ccc;
    }

    .profile-container h2 {
        text-align: center;
        margin-bottom: 25px;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    .form-group input {
        width: 100%;
        padding: 10px;
        box-sizing: border-box;
    }

    .avatar {
        display: block;
        width: 120px;
        height: 120px;
        object-fit: cover;
        border-radius: 50%;
        margin: 10px auto 20px;
    }

    button {
        width: 100%;
        padding: 10px;
        border: none;
        cursor: pointer;
    }
</style>

</head>

<body>

<div class="profile-container">

    <h2>Thông tin cá nhân</h2>

    <c:if test="${not empty profile.images}">
        <img
            src="${pageContext.request.contextPath}/uploads/${profile.images}"
            class="avatar"
            alt="Avatar">
    </c:if>

    <form action="${pageContext.request.contextPath}/profile"
          method="post"
          enctype="multipart/form-data">

        <div class="form-group">
            <label>Họ và tên</label>

            <input type="text"
                   name="fullname"
                   value="${profile.fullname}"
                   required>
        </div>

        <div class="form-group">
            <label>Số điện thoại</label>

            <input type="text"
                   name="phone"
                   value="${profile.phone}"
                   required>
        </div>

        <div class="form-group">
            <label>Ảnh đại diện</label>

            <input type="file"
                   name="images"
                   accept="image/*">
        </div>

        <button type="submit">
            Cập nhật Profile
        </button>

    </form>

</div>

</body>
</html>