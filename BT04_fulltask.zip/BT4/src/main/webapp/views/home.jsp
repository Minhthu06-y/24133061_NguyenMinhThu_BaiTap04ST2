<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">

<title>Trang chủ - Campanula</title>

<style>
.container {
	width: 90%;
	margin: 40px auto;
}

.title {
	text-align: center;
	margin-bottom: 40px;
	color: #2c3e50;
	font-size: 32px;
}

.product-grid {
	display: grid;
	grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
	gap: 25px;
}

.product-card {
	background: white;
	border-radius: 12px;
	overflow: hidden;
	box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
	transition: 0.3s;
}

.product-card:hover {
	transform: translateY(-8px);
}

.product-image {
	width: 100%;
	height: 220px;
	object-fit: cover;
}

.product-info {
	padding: 20px;
}

.product-name {
	font-size: 20px;
	font-weight: bold;
	color: #2c3e50;
	margin-bottom: 10px;
}

.product-description {
	color: #777;
	height: 45px;
	overflow: hidden;
	margin-bottom: 15px;
}

.product-price {
	color: #e74c3c;
	font-size: 20px;
	font-weight: bold;
	margin-bottom: 20px;
}

.product-button {
	display: block;
	text-align: center;
	background: #3498db;
	color: white;
	padding: 12px;
	border-radius: 6px;
	text-decoration: none;
}

.empty {
	text-align: center;
	font-size: 20px;
	color: #777;
}

.view-all {
	text-align: center;
	margin-top: 40px;
}

.view-all a {
	display: inline-block;
	background: #2c3e50;
	color: white;
	padding: 14px 30px;
	border-radius: 6px;
	text-decoration: none;
}
</style>

</head>

<body>

	<div class="container">

		<h1 class="title">SẢN PHẨM MỚI NHẤT</h1>

		<c:if test="${empty productList}">
			<div class="empty">Chưa có sản phẩm nào!</div>
		</c:if>

		<div class="product-grid">

			<c:forEach items="${productList}" var="product">

				<div class="product-card">

					<c:choose>

						<c:when test="${not empty product.images}">
							<img src="${product.images}" class="product-image"
								onerror="this.onerror=null;
                            this.src='https://placehold.co/300x220?text=No+Image';">
						</c:when>

						<c:otherwise>
							<img src="https://placehold.co/300x220?text=No+Image"
								class="product-image">
						</c:otherwise>

					</c:choose>

					<div class="product-info">

						<div class="product-name">${product.productname}</div>

						<div class="product-description">${product.description}</div>

						<div class="product-price">
							<fmt:formatNumber value="${product.price}" type="number"
								groupingUsed="true" maxFractionDigits="0" />
							VNĐ
						</div>

						<a
							href="${pageContext.request.contextPath}/product-detail?id=${product.id}"
							class="product-button"> Xem chi tiết </a>

					</div>

				</div>

			</c:forEach>

		</div>

		<div class="view-all">
			<a href="${pageContext.request.contextPath}/product"> Xem tất cả
				sản phẩm </a>
		</div>

	</div>

</body>
</html>